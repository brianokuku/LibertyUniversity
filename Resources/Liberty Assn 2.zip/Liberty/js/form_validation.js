////JQuery to valdate the form

$('#apply_button').click(function(){
	var degree = $('#degree').val();
	var course = $('#course').val();	
	var fname = $('#fname').val();
	var lname = $('#lname').val();
	var email = $('#email').val();
	var phone = $('#phone').val();
	var address = $('#address').val();

	
	if(degree&&course&&fname&&lname&&email&&phone&&address){
		alert("Successfully applied");
	}else{
		if(!degree){
			$('#degree').css({"border":"2px solid #990000","color":"#990000"});
			$('#warn1').html("Kindly fill in this field");
		}else{
			$('#degree').css({"border":"1px solid #AAA","color":"#555"});
			$('#warn1').html("");
		}
		
		if(!course){
			$('#course').css({"border":"2px solid #990000","color":"#990000"});
			$('#warn2').html("Kindly fill in this field");
		}else{
			$('#course').css({"border":"1px solid #AAA","color":"#555"});
			$('#warn2').html("");
		}
		
		if(!fname){
			$('#fname').css({"border":"1px solid #990000","color":"#990000"});
		}else{
			$('#fname').css({"border":"1px solid #555","color":"#555"});
		}
		
		if(!lname){
			$('#lname').css({"border":"1px solid #990000","color":"#990000"});
		}else{
			$('#lname').css({"border":"1px solid #555","color":"#555"});
		}
		
		if(!email){
			$('#email').css({"border":"1px solid #990000","color":"#990000"});
		}else{
			$('#email').css({"border":"1px solid #555","color":"#555"});
		}
		
		if(!phone){
			$('#phone').css({"border":"1px solid #990000","color":"#990000"});
		}else{
			$('#phone').css({"border":"1px solid #555","color":"#555"});
		}
		
		if(!address){
			$('#address').css({"border":"1px solid #990000","color":"#990000"});
		}else{
			$('#address').css({"border":"1px solid #555","color":"#555"});
		}
		
	}
});


/*The tell me more JQuery*/

$('#more_info').click(function(){
	$('#more').slideToggle(400);
});